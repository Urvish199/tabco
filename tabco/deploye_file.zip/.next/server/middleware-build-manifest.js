globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/5bbf28cb21b88e17.js",
      "static/chunks/turbopack-423f55b4de7e1bd0.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/5bbf28cb21b88e17.js",
      "static/chunks/turbopack-32e5ab26737038c2.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/972964de8527a76d.js",
    "static/chunks/6ade8622d5cd9138.js",
    "static/chunks/7f4fa938a6d8dbee.js",
    "static/chunks/7c760bf6aa73eefa.js",
    "static/chunks/turbopack-4a7a5d621b5322ff.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];