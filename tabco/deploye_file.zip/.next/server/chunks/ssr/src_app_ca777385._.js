module.exports=[68758,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},19362,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(68758).default,width:256,height:256}}];

//# sourceMappingURL=src_app_ca777385._.js.map