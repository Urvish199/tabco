__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/5bbf28cb21b88e17.js",
  "static/chunks/turbopack-423f55b4de7e1bd0.js"
])
