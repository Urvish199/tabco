__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/5bbf28cb21b88e17.js",
  "static/chunks/turbopack-32e5ab26737038c2.js"
])
